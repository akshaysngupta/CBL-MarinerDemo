---
title: netplan
section: 5
author:
- Mathieu Trudel-Lapierre (<cyphermox@ubuntu.com>)
- Martin Pitt (<martin.pitt@ubuntu.com>)
- Lukas Märdian (<slyon@ubuntu.com>)
...

# NAME

netplan - YAML network configuration abstraction for various backends

# SYNOPSIS

**netplan** [ *COMMAND* | help ]

# COMMANDS

See **netplan help** for a list of available commands on this system.

# DESCRIPTION
