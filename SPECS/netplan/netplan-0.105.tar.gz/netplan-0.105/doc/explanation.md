# Explanation

## Design
* [Netplan Design](https://netplan.io/design)
  – Network configuration abstraction via systemd-generator

## FAQs
* [Netplan FAQs](https://netplan.io/faq)
  – Find answers to common questions