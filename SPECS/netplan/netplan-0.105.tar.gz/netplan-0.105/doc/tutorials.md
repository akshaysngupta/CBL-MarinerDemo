# Tutorials

Here you can find some external blog posts, describing the usage of Netplan on different systems.

## Ubuntu 22.04 LTS
* <https://vitux.com/how-to-configure-networking-with-netplan-on-ubuntu/>

## Ubuntu 20.04 LTS
* <https://linux-on-z.blogspot.com/p/using-netplan-on-ibm-z.html>
* <https://linuxconfig.org/netplan-network-configuration-tutorial-for-beginners>
* <https://www.serverlab.ca/tutorials/linux/administration-linux/how-to-configure-networking-in-ubuntu-20-04-with-netplan/>

## Ubuntu 18.04 LTS
* <https://www.linux.com/topic/distributions/how-use-netplan-network-configuration-tool-linux/>
* <https://linuxhint.com/install_netplan_ubuntu/>