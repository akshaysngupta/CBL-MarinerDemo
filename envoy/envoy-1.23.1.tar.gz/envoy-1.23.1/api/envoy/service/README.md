Protocol buffer definitions for gRPC and REST services.

Visibility should be constrained to none (default).
