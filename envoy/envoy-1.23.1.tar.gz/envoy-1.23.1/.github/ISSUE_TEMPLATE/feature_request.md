---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement,triage
assignees: ''

---

*Title*: *One line description*

*Description*:
>Describe the desired behavior, what scenario it enables and how it
would be used.

[optional *Relevant Links*:]
>Any extra documentation required to understand the issue.
