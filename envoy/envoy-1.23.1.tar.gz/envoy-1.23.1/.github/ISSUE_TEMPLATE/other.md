---
name: Other
about: Questions, design proposals, tech debt, etc.
title: ''
labels: triage
assignees: ''

---

**If you are reporting *any* crash or *any* potential security issue, *do not*
open an issue in this repo. Please report the issue via emailing
envoy-security@googlegroups.com where the issue will be triaged appropriately.**

*Title*: *One line description*

*Description*:
>Describe the issue.

[optional *Relevant Links*:]
>Any extra documentation required to understand the issue.
